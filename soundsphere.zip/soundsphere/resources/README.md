# soundsphere-resources
noto fonts:  
https://www.google.com/get/noto/help/cjk/  
https://www.google.com/get/noto/  
  
midi background: awemanrank100#9373
